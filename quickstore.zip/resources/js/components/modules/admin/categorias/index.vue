<template>
  <section class="container col-12 mt-3">
    <div class="col-12 text-center pb-2">
      <el-select
        v-model="catSearch"
        clearable
        filterable
        placeholder="Buscar Categoría"
        suffix-icon="el-icon-search"
      >
        <el-option
          v-for="item in catList"
          :key="item.value"
          :label="item.label"
          :value="item.value"
        ></el-option>
      </el-select>
      <el-button type="primary" icon="el-icon-search" size="mini" round>Buscar</el-button>
    </div>
    <div class="table-responsive pb-5">
      <table class="categories-table table table-sm table-hover bordered">
        <thead class="table-active">
          <tr>
            <th class="text-center text-nowrap" style="width:1%">
              <router-link :to="{name:'admin.categorias.create'}">
                <el-button type="warning" icon="el-icon-plus" size="mini" circle></el-button>
              </router-link>
            </th>
            <th class="text-center text-nowrap" style="width:20%">Banner</th>
            <th>Nombre</th>
            <th class="text-center">Posición</th>
            <th class="text-center">Estado</th>
            <th class="text-center">Tipo</th>
            <!-- <th class="text-center"></th> -->
            <th class="text-center"></th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="cat in catList" :key="cat.id" class="text-nowrap">
            <td class="text-center align-middle">
              <router-link :to="{name: 'admin.categorias.edit', params: { id: cat.value }}">
                <el-button type="primary" icon="el-icon-edit" size="mini" circle></el-button>
              </router-link>
              <el-button
                type="info"
                icon="el-icon-delete"
                size="mini"
                circle
                @click="deleteCategory(cat.value)"
                v-if="cat.value > 1"
              ></el-button>
            </td>
            <td class="align-middle">
              <div class="img-fluid text-center" style="max-height:70px; overflow: hidden">
                <img :src="`/img/categories/${cat.image}`" :alt="cat.label" style="max-width:120px" />
              </div>
            </td>
            <td class="align-middle">
              <!-- <span class="fas fa-eye"></span> -->
              {{cat.label}}
            </td>
            <td class="text-center text-nowrap align-middle" style="width:10%">{{cat.position}}</td>
            <td class="text-center text-nowrap align-middle" style="width:10%">{{cat.status}}</td>
            <td class="text-center text-nowrap align-middle" style="width:10%">{{cat.type}}</td>
            <!-- <td class="text-center align-middle">
              <el-button type="info" size="mini" round>
                <i class="fas fa-sitemap"></i>
                Subcat
              </el-button>
            </td>-->
            <td class="text-center align-middle">
              <el-button type="info" size="mini" round>
                <i class="fab fa-apple"></i>
                Productos
              </el-button>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </section>
</template>

<script>
export default {
  props: ["ruta"],
  data() {
    return {
      catList: [],
      catSearch: "",
    };
  },
  mounted() {
    this.getAllCategories();
  },
  methods: {
    //   Cargar Categorías Guardadas
    getAllCategories: function () {
      this.catList = [];
      axios
        .get("/categories")
        .then((response) => {
          response.data.forEach((element) => {
            this.catList.push({
              value: element.id,
              label: element.nombre,
              image: element.image,
              position: element.position,
              status: element.estado_id,
              type: element.tipo_id,
            });
          });
        })
        .catch((error) => {
          //no estas autenticado
          if (error.response.status == 401) {
            // this.app.Toastr.error("Caduco su Sesión");
            // localStorage.removeItem("user-authenticate");
            // this.$router.push("/login");
            console.log(error.response.status);
          }
        });
    },
    deleteCategory: function (id) {
      this.$confirm(
        "Esta a punto de eliminar esta categoría. ¿Desea continuar?",
        "Mensaje",
        {
          confirmButtonText: "Si",
          cancelButtonText: "No",
          type: "warning",
        }
      )
        .then(() => {
          axios.delete(`/categories/${id}`).then((response) => {
            if (response) {
              this.$message({
                type: "success",
                message: "Categoría eliminada",
              });
              this.getAllCategories();
            }
          });
        })
        .catch(() => {
          this.$message({
            type: "info",
            message: "Eliminación cancelada",
          });
        });
    },
  },
};
</script>

<style>
</style>
