<template>
  <div class="col-12 p-0">
    <footer class="fixed-bottom d-none d-md-block col-12 m-auto p-0">
      <div class="bg-dark">
        <p class="text-center p-0 m-0">
          <small class="text-white">Copyright &copy;</small>
        </p>
      </div>
    </footer>
  </div>
</template>

<script>
export default {};
</script>

<style>
footer {
  max-width: 960px !important;
}
</style>
