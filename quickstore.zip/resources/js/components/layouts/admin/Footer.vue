<template>
  <footer class="fixed-bottom col-12 col-sm-8 m-auto p-0">
    <div class="bg-dark">
      <p class="text-center p-0 m-0">
        <small class="text-white">Copyright &copy;</small>
      </p>
    </div>
  </footer>
</template>

<script>
export default {};
</script>

<style>
</style>
