<!-- jQuery -->
<script src="{{asset('js/app.js')}}"></script>
<script src="{{asset('js/plantilla.js')}}"></script>
