<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<?php echo $__env->make('parts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <body>
        <div class="wrapper" id="app">
            <App ruta="<?php echo e(route('basepath')); ?>"></App>
        </div>
        <?php echo $__env->make('parts.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </body>
</html>
<?php /**PATH C:\laragon\www\quickstore\resources\views/app.blade.php ENDPATH**/ ?>