<?php use \App\Http\Controllers\metaTagController; $metaInfo = metaTagController::metaBuilder(url()->current())?>
<?php if(sizeof($metaInfo)>1): ?>

<meta property="og:title" content="<?php echo e($metaInfo['site']['storename'].' | '.$metaInfo['product']['nombre']); ?>">
<meta property="og:site_name" content="<?php echo e($metaInfo['site']['storename']); ?>">
<meta property="og:url" content="<?php echo e(url('/')); ?>">
<meta property="og:description" content="<?php echo e($metaInfo['product']['short_des']); ?>">
<meta property="og:type" content="article">
<meta property="og:image" content="<?php echo e(url('/img/products/'.$metaInfo['product']['image'])); ?>">

<!-- Open Graph / Facebook -->
<meta property="og:type" content="article">
<meta property="og:url" content="<?php echo e(url('/')); ?>">
<meta property="og:title" content="<?php echo e($metaInfo['site']['storename'].' | '.$metaInfo['product']['nombre']); ?>">
<meta property="og:description" content="<?php echo e($metaInfo['product']['short_des']); ?>">
<meta property="og:image" content="<?php echo e(url('/img/products/'.$metaInfo['product']['image'])); ?>">

<!-- Twitter -->
<meta property="twitter:card" content="summary_large_image">
<meta property="twitter:url" content="<?php echo e(url('/')); ?>">
<meta property="twitter:title" content="<?php echo e($metaInfo['site']['storename'].' | '.$metaInfo['product']['nombre']); ?>">
<meta property="twitter:description" content="<?php echo e($metaInfo['product']['short_des']); ?>">
<meta property="twitter:image" content="<?php echo e(url('/img/products/'.$metaInfo['product']['image'])); ?>">



<?php else: ?>
<meta property="og:title" content="<?php echo e($metaInfo['site']['storename']); ?>">
<meta property="og:site_name" content="<?php echo e($metaInfo['site']['storename']); ?>">
<meta property="og:url" content="<?php echo e(url('/')); ?>">
<meta property="og:description" content="Mi pequeña tienda">
<meta property="og:type" content="article">
<meta property="og:image" content="<?php echo e(url('/img/settings/'.$metaInfo['site']['image'])); ?>">

<!-- Open Graph / Facebook -->
<meta property="og:type" content="article">
<meta property="og:url" content="<?php echo e(url('/')); ?>">
<meta property="og:title" content="<?php echo e($metaInfo['site']['storename']); ?>">
<meta property="og:description" content="Mi pequeña tienda">
<meta property="og:image:width" content="600" />
<meta property="og:image:height" content="600" />
<meta property="og:image" content="<?php echo e(url('/img/settings/'.$metaInfo['site']['image'])); ?>">

<!-- Twitter -->
<meta property="twitter:card" content="summary_large_image">
<meta property="twitter:url" content="<?php echo e(url('/')); ?>">
<meta property="twitter:title" content="<?php echo e($metaInfo['site']['storename']); ?>">
<meta property="twitter:description" content="Mi pequeña tienda">
<meta property="twitter:image" content="<?php echo e(url('/img/settings/'.$metaInfo['site']['image'])); ?>">
    
<?php endif; ?>
<?php /**PATH C:\laragon\www\quickstore\resources\views/parts/meta.blade.php ENDPATH**/ ?>