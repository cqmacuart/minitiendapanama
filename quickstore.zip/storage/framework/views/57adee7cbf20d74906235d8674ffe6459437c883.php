<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<?php echo $__env->make('parts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <body>
        <div class="wrapper" id="app">
            <?php if(Auth::check()): ?>
            <Admin ruta="<?php echo e(route('basepath')); ?>"></Admin>
            <?php else: ?>
            <Auth ruta="<?php echo e(route('basepath')); ?>"></Auth>
            <?php endif; ?>
        </div>
        <?php echo $__env->make('parts.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </body>
</html>
<?php /**PATH C:\laragon\www\quickstore\resources\views/admin.blade.php ENDPATH**/ ?>