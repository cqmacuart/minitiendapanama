<!-- jQuery -->
<script src="<?php echo e(asset('js/app.js')); ?>"></script>
<script src="<?php echo e(asset('js/plantilla.js')); ?>"></script>
<?php /**PATH C:\laragon\www\quickstore\resources\views/parts/scripts.blade.php ENDPATH**/ ?>